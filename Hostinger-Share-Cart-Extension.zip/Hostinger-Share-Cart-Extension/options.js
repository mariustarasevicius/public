document.body.onload = function() {
    chrome.storage.sync.get("alias", function (data) {
        if (data.hasOwnProperty('alias')) {
            document.getElementById("alias").value = data.alias;
        } else {
            document.getElementById("alias").value = "";
        }
    });
}

document.getElementById("save").addEventListener('click', function () {
    chrome.storage.sync.set({ "alias" : document.getElementById("alias").value }, function() {
        document.getElementById("alias").className = "success";
        setTimeout(function() { document.getElementById("alias").remove = "success"; }, 5000);
    });
});
