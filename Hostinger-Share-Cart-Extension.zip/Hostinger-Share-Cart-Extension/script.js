chrome.extension.sendRequest("getStorageData", function(response) {
    console.log("response:", response);
}
