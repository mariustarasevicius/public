chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.cookies.getAll({},function (cookies) {
        chrome.extension.getBackgroundPage().console.log(cookies);
        chrome.tabs.getSelected(null, function (tab) {
            makeRequest(tab.url);
        });
    });
});

function makeRequest(tablink) {
    chrome.storage.sync.get('alias', function (data) {
        if(data.hasOwnProperty('alias') && data.alias != '') {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", tablink + 'share-url', true);
            xhr.onload  = function() {
                if (xhr.status == 200) {
                    var obj = JSON.parse(xhr.responseText);
                    const el = document.createElement('textarea');
                    el.value = obj['url'] + '?cs-campaign=' + data.alias;
                    document.body.appendChild(el);
                    el.select();
                    document.execCommand('copy');
                    document.body.removeChild(el);
                    chrome.browserAction.setIcon({path: 'iconG.png'});
                    resetIcon();
                } else {
                    chrome.browserAction.setIcon({path: 'iconR.png'});
                    resetIcon();
                }
            }
            xhr.onloadstart = function () {
                chrome.browserAction.setIcon({path: "iconD.png"});
            }

            xhr.onerror = function() {
                chrome.browserAction.setIcon({path: 'iconR.png'});
                resetIcon();
            }
            xhr.send();
        } else {
            alert('Set your alias in extension\'s options');
            chrome.browserAction.setIcon({path: 'iconR.png'});
            resetIcon();
        }
    });
}

function resetIcon() {
    setTimeout(function() { chrome.browserAction.setIcon({path: 'icon.png'}) }, 5000);
}
